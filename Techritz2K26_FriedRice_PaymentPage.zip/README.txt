FRIED RICE PAYMENT PAGE

What this does:
One QR on your poster can open this page, where students choose between the two
payment scanners.

Files:
- index.html
- scanner-1.png  (SBI ending 7642)
- scanner-2.png  (SBI ending 3844)

IMPORTANT:
The final poster QR must point to the PUBLIC URL of this page. A QR cannot point
to these local files and work on students' phones.

Easy hosting:
1. Create a new public GitHub repository, for example: techritz-fried-rice-payment
2. Upload all 3 files from this folder.
3. In GitHub: Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save.
4. GitHub will give you a public Pages URL.
5. Send that URL to me. I can then create the final single-QR poster using that URL.

Do not change the scanner image files after creating the final QR.
